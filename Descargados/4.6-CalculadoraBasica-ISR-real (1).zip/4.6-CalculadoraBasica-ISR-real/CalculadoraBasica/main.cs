﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CalculadoraBasica
{
    public partial class main : Form
    {
        //Creamos los arreglos con los datos de la tabla de ISR
        private double[] limitInfData;
        private double[] limitSupData;
        private double[] cuotaFixData;
        private double[] percentData;

        public main()
        {
            InitializeComponent();
        }

        private void button_Calcular_Click(object sender, EventArgs e)
        {
            if (this.textBox1.Text != "")
            {
                //Obtenemos el sueldo Neto introducido por el usuario
                double sueldoBruto = Convert.ToDouble(this.textBox1.Text);

                if (sueldoBruto > 0)
                {//Si el sueldo neto es mayor a cero, continuar
                    //Creamos los arreglos de datos
                    createISRTable();
                    int tam = this.limitInfData.Length;
                    double sueldoNeto, excLimitInf, ISR, limitInf, limitSup, cuotaFix, percent;

                    for (int i = 0; i < tam; i++)
                    {//Iteramos tantas veces como el tamano del arreglo
                        if ((sueldoBruto >= limitInfData[i]) && (sueldoBruto <= limitSupData[i]))
                        {
                            limitInf = limitInfData[i];
                            limitSup = limitSupData[i];
                            cuotaFix = cuotaFixData[i];
                            percent = percentData[i]/100.0;

                            //Aplicamos las operaciones
                            excLimitInf = sueldoBruto - limitInf;
                            ISR = cuotaFix + (excLimitInf * percent);
                            sueldoNeto = sueldoBruto - ISR;

                            //Mandamos mensaje
                            string text = "ISR: " + ISR.ToString() + "\n";
                            text += "Sueldo Neto: " + sueldoNeto.ToString() + "\n";
                            MessageBox.Show(text);

                            break;//Rompemos la iteracion
                        }
                    }
                }
            }
        }

        //Creamos los arreglos de datos y los llenamos
        private void createISRTable()
        {
            //Data from: http://losimpuestos.com.mx/tablas-isr-2015/
            limitInfData = new double[11];
            limitSupData = new double[11];
            cuotaFixData = new double[11];
            percentData = new double[11];

            //Datos de limite inferior
            limitInfData[0] = 0.01;
            limitInfData[1] = 496.08;
            limitInfData[2] = 4210.42;
            limitInfData[3] = 7399.43;
            limitInfData[4] = 8601.51;
            limitInfData[5] = 10298.36;
            limitInfData[6] = 20770.30;
            limitInfData[7] = 32736.84;
            limitInfData[8] = 62500.01;
            limitInfData[9] = 83333.34;
            limitInfData[10] = 250000.01;

            //Datos de limite superior
            limitSupData[0] = 496.07;
            limitSupData[1] = 4210.41;
            limitSupData[2] = 7399.42;
            limitSupData[3] = 8601.50;
            limitSupData[4] = 10298.35;
            limitSupData[5] = 20770.29;
            limitSupData[6] = 32736.83;
            limitSupData[7] = 62500.00;
            limitSupData[8] = 83333.33;
            limitSupData[9] = 250000.00;
            limitSupData[10] = Double.PositiveInfinity;

            //Cuota Fija
            cuotaFixData[0] = 0.0;
            cuotaFixData[1] = 9.52;
            cuotaFixData[2] = 247.24;
            cuotaFixData[3] = 594.21;
            cuotaFixData[4] = 786.54;
            cuotaFixData[5] = 1090.61;
            cuotaFixData[6] = 3327.42;
            cuotaFixData[7] = 6141.95;
            cuotaFixData[8] = 15070.90;
            cuotaFixData[9] = 21737.57;
            cuotaFixData[10] = 78404.23;

            //Porcentaje sobre el Excedente del Limite Inferior
            percentData[0] = 1.92;
            percentData[1] = 6.4;
            percentData[2] = 10.88;
            percentData[3] = 16.0;
            percentData[4] = 17.92;
            percentData[5] = 21.36;
            percentData[6] = 23.52;
            percentData[7] = 30.0;
            percentData[8] = 32.0;
            percentData[9] = 34.0;
            percentData[10] = 35.0;
        }

    }
}
