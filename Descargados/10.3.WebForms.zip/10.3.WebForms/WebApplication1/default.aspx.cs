﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication1
{
    public partial class _default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void button_Hello_Click(object sender, EventArgs e)
        {//Guarda todos los elementos en el ComboBox/DropDownList
            string text = this.textBox_Hello.Text;
            this.dropDownList_Hello.Items.Add(text);
            this.label_Hello.Text = text;
            this.textBox_Hello.Text = "";
        }

        protected void buttons_Redirect_Click(object sender, EventArgs e)
        {//Redirecciona a otra pagina mandando datos
            //Obtiene los elementos a guardar
            ListItemCollection items = this.dropDownList_Hello.Items;
            Session.Add("DropDown_Items", items);
            this.Response.Redirect("OtherPage.aspx");
        }
    }
}