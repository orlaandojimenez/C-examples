﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication1
{
    public partial class OtherPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {//Si la llamada no es un PostBack
                try
                {
                    ListItemCollection items = (ListItemCollection)this.Session["DropDown_Items"];
                    if (items != null)
                        this.addElements(items);
                    else
                        Response.Redirect("default.aspx");
                }
                catch
                {
                    Response.Redirect("default.aspx");
                }
            }
        }

        private void addElements(ListItemCollection items)
        {
            for (int i = 0; i < items.Count; i++)
            {
                string text = items[i].Value;
                TableRow row = new TableRow();
                TableCell cellNum = new TableCell();
                TableCell cellVal = new TableCell();
                cellNum.Text = i.ToString();
                cellVal.Text = text;
                row.Cells.Add(cellNum);
                row.Cells.Add(cellVal);
                this.Table1.Rows.Add(row);
            }
        }
    }
}