﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication1
{
    public partial class _default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }


        [System.Web.Services.WebMethod]
        public static string doLogin(string userid, string pass)
        {
            string result = "";

            if (userid != "" && pass != "")
            {
                SqlParameter parameter1 = new SqlParameter("@userId", userid);
                DataSet dataSet = SQLManager.EjecutarQueryConSP("sp_getUserByID", parameter1);
                if (dataSet != null)
                {
                    try
                    {
                        string msg = "";
                        //Obtenemos el pass y nombre
                        //Tables[index] - index 0 puesto que se regresa una tabla
                        //Rows[0][1] - Primera fila segunda columna
                        //Rows[0][2] - Primera fila tercera columna
                        string bdName = dataSet.Tables[0].Rows[0][1].ToString();
                        string bdPass = dataSet.Tables[0].Rows[0][2].ToString();

                        if (pass.Trim() == bdPass.Trim())
                            msg = "OK - " + bdName;
                        else
                            msg = "El usuario y password no coinciden";
                        result = msg;
                    }
                    catch (Exception ex)
                    {
                        result = "ERROR";
                    }
                }
                else
                {//El DataSet es nulo, no hay datos regresados
                    result = "El usuario no existe en nuestra base de datos";
                }
            }

            return result;
        }
    }
}