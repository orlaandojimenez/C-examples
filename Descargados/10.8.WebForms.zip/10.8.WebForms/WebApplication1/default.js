﻿function doLogin() {
    var useridVal = $("#text_userID").val();
    var passVal = $("#text_userPass").val();

    $.ajax({
        type: "GET",
        url: "doLogin.aspx/doLogin",    //La url ahora es ResponsePage.aspx/MethodName
        dataType: "json",               //Los WebMethods regresan un JSON por default
        data:
        {
            userid: useridVal,
            pass: passVal
        },
        success:
            function (data)
            {//En un WebMethod se regresa la info en el attb. "d" del json
                var response = data.d;
                if (response == "ERROR") {
                    var msg = "Error consultando la base de datos";
                    displayMsg(msg);
                }
                else if (response != "") {//OK, show the user data
                    displayMsg(response);
                }
                else {//No data, error
                    var msg = "Error desconocido";
                    displayMsg(msg);
                }
            },
        error:
            function ()
            {
                var msg = "Error en la llamada al servidor";
                msg += "estas seguro que tienes internet?";
                displayMsg(msg);
            }
    });

}

function displayMsg(msg) {//Usamos js/Bootbox para desplegar mensajes hermosos
    bootbox.alert(msg);
}