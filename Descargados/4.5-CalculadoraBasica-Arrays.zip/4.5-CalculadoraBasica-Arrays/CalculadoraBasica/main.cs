﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CalculadoraBasica
{
    public partial class main : Form
    {
        public main()
        {
            InitializeComponent();
        }

        private void button_Calcular_Click(object sender, EventArgs e)
        {
            arregloAuto();
        }

        private void arregloManual()
        {
            string[] productos = new string[3];
            int[] precios = new int[3];

            productos[0] = "Naranja";
            productos[1] = "Papaya";
            productos[2] = "Manzana";

            precios[0] = 1;
            precios[1] = 5;
            precios[2] = 3;

            string text = productos[0] + " - " + precios[0] + "\n";
            text += productos[1] + " - " + precios[1] + "\n";
            text += productos[2] + " - " + precios[2];

            MessageBox.Show(text);
        }

        private void arregloAuto()
        {
            string[] productos = new string[3];
            int[] precios = new int[3];

            productos[0] = "Naranja";
            productos[1] = "Papaya";
            productos[2] = "Manzana";

            precios[0] = 1;
            precios[1] = 5;
            precios[2] = 3;

            string text = "";
            for (int i = 0; i < 3; i++)
            {
                text += productos[i] + " - " + precios[i] + "\n";
            }

            MessageBox.Show(text);
        }

    }
}
