﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace WebApplication1
{
    public partial class doLogin : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string userID = Request.QueryString["userid"];
                string pass = Request.QueryString["pass"];

                if (userID != "" && pass != "")
                {
                    SqlParameter parameter1 = new SqlParameter("@userId", userID);
                    DataSet dataSet = SQLManager.EjecutarQueryConSP("sp_getUserByID", parameter1);
                    if (dataSet != null)
                    {
                        try
                        {
                            string msg = "";
                            //Obtenemos el pass y nombre
                            //Tables[index] - index 0 puesto que se regresa una tabla
                            //Rows[0][1] - Primera fila segunda columna
                            //Rows[0][2] - Primera fila tercera columna
                            string bdName = dataSet.Tables[0].Rows[0][1].ToString();
                            string bdPass = dataSet.Tables[0].Rows[0][2].ToString();

                            if (pass.Trim() == bdPass.Trim())
                                msg = "OK - " + bdName;
                            else
                                msg = "El usuario y password no coinciden";
                            Response.Write(msg);
                        }
                        catch(Exception ex)
                        {
                            Response.Write("ERROR");
                        }
                    }
                    else
                    {//El DataSet es nulo, no hay datos regresados
                        Response.Write("El usuario no existe en nuestra base de datos");
                    }
                }
            }

        }
    }
}