﻿function doLogin()
{
    var useridVal = $("#text_userID").val();
    var passVal = $("#text_userPass").val();

    $.ajax({
        type: "GET",
        url: "doLogin.aspx",
    dataType: "html", 
    data:                
    {
        userid: useridVal,
        pass: passVal
        },
    success:
        function (data)
        {
            if(data == "ERROR")
            {
                var msg = "Error consultando la base de datos";
                displayMsg(msg);
            }
            else if(data != "")
            {//OK, show the user data
                displayMsg(data);
            }
            else
            {//No data, error
                var msg = "Error desconocido";
                displayMsg(msg);
            }
        },
    error:
        function ()
        {
            var msg = "Error en la llamada al servidor";
            msg += "estas seguro que tienes internet?";
            displayMsg(msg);
        }
    });

}

function displayMsg(msg)
{//Usamos js/Bootbox para desplegar mensajes hermosos
    bootbox.alert(msg);
}