﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CalculadoraBasica
{
    public partial class main : Form
    {
        public main()
        {
            InitializeComponent();
        }

        private void button_Calcular_Click(object sender, EventArgs e)
        {
            //Usamos la propiedad Text de la instancia comboBox1 de la clase ComboBox
            //para accesar al valor seleccionado (esto no es robusto pero sirve para nuestro ejemplo)
            String operador = this.comboBox1.Text;
            int resultado = 0;
            int valor1 = 0;
            int valor2 = 0;

            //Obtenemos los valores de los TextBox's
            valor1 = Convert.ToInt32(this.textBox_Val1.Text);
            valor2 = Convert.ToInt32(this.textBox_Val2.Text);

            if (operador == "+")
            {//SUMA
                resultado = valor1 + valor2;
            }
            else if (operador == "-")
            {//RESTA
                resultado = valor1 - valor2;
            }
            else if (operador == "*")
            {//MULTIPLICACION
                resultado = valor1 * valor2;
            }
            else if (operador == "/")
            {//DIVISION
                resultado = valor1 / valor2;
            }
            else if(operador == "pow")
            {//POTENCIA
                int i = 1;
                resultado = valor1;
                for(i = 1; i < valor2; i++)
                {//Repetir tantas veces como valor2
                    resultado = resultado * valor1;
                }
            }
            else
            {//SIN OPERADOR
                MessageBox.Show("Selecciona un operador");
            }

            //Colocamos el resultado en el Label
            this.label_Resultado.Text = resultado.ToString();
        }
    }
}
