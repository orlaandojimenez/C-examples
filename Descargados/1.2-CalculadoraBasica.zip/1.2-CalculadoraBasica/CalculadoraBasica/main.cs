﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CalculadoraBasica
{
    public partial class main : Form
    {
        public main()
        {
            InitializeComponent();
        }

        private void button_Calcular_Click(object sender, EventArgs e)
        {
            int numero1;

            numero1 = Convert.ToInt32(this.textBox_Val1.Text);

            if (numero1 >= 90)
            {
                MessageBox.Show("Eres un matado");
            }
            else
            {
                if (numero1 >= 70)
                {
                    MessageBox.Show("Panzaste");
                }
                else
                {
                    MessageBox.Show("Nos vemos en segundas");
                }
            }
        }
    }
}
