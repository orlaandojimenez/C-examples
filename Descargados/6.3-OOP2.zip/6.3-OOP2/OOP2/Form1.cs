﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace OOP2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        #region EVENTOS DE FORMULARIO
        private void Form1_Load(object sender, EventArgs e)
        {
            //El formulario se esta cargando, intentamos buscar
            //la imagen a colocar en el PictureBox
            this.pictureBox1.Image = new Bitmap(OOP2.Properties.Resources.fime);

            this.comboBox1.Items.Add("Item 1");
            this.comboBox1.Items.Add("Item 2");
            this.comboBox1.Items.Add("Item 3");
        }
        #endregion

        #region CHECKED CHANGED EVENT - CheckBox
        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (this.checkBox1.Checked)
                this.labelChecks.Text = "Checked 1";
            else
                this.labelChecks.Text = "Unchecked 1";
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (this.checkBox2.Checked)
                this.labelChecks.Text = "Checked 2";
            else
                this.labelChecks.Text = "Unchecked 2";
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            if (this.checkBox3.Checked)
                this.labelChecks.Text = "Checked 3";
            else
                this.labelChecks.Text = "Unchecked 3";
        }
        #endregion

        #region CHECKED CHANGED EVENT - ReadioButton
        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            if (this.radioButton1.Checked)
                this.labelRadios.Text = "RadioButton1 checked";
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            if (this.radioButton2.Checked)
                this.labelRadios.Text = "RadioButton2 checked";
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            if (this.radioButton3.Checked)
                this.labelRadios.Text = "RadioButton3 checked";
        }
        #endregion

        #region COMBOBOX region
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {//ESTE METODO SE EJECUTA CADA VEZ QUE SE CAMBIA EL ITEM SELECCIONADO
            this.labelCombo.Text = this.comboBox1.SelectedItem.ToString();
        }

        private void buttonCombo_Click(object sender, EventArgs e)
        {
            if(this.comboBox1.SelectedIndex >= 0)
            {//Si se ha seleccionado algun item
                string itemText = this.comboBox1.SelectedItem.ToString();
                switch(itemText)
                {
                    case "Item 1":
                        MessageBox.Show("=)");
                        break;

                    case "Item 2":
                        MessageBox.Show("=(");
                        break;

                    case "Item 3":
                        MessageBox.Show(":O");
                        break;
                }

            }
        }
        #endregion
    }
}
