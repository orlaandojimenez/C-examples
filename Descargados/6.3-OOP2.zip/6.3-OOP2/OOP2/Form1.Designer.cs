﻿namespace OOP2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBoxChecks = new System.Windows.Forms.GroupBox();
            this.groupBoxRadios = new System.Windows.Forms.GroupBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.groupBoxCombo = new System.Windows.Forms.GroupBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.buttonCombo = new System.Windows.Forms.Button();
            this.labelCombo = new System.Windows.Forms.Label();
            this.labelChecks = new System.Windows.Forms.Label();
            this.labelRadios = new System.Windows.Forms.Label();
            this.groupBoxChecks.SuspendLayout();
            this.groupBoxRadios.SuspendLayout();
            this.groupBoxCombo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBoxChecks
            // 
            this.groupBoxChecks.Controls.Add(this.labelChecks);
            this.groupBoxChecks.Controls.Add(this.checkBox3);
            this.groupBoxChecks.Controls.Add(this.checkBox2);
            this.groupBoxChecks.Controls.Add(this.checkBox1);
            this.groupBoxChecks.Location = new System.Drawing.Point(3, 12);
            this.groupBoxChecks.Name = "groupBoxChecks";
            this.groupBoxChecks.Size = new System.Drawing.Size(172, 167);
            this.groupBoxChecks.TabIndex = 0;
            this.groupBoxChecks.TabStop = false;
            this.groupBoxChecks.Text = "GroupBox de CheckBoxes";
            // 
            // groupBoxRadios
            // 
            this.groupBoxRadios.Controls.Add(this.labelRadios);
            this.groupBoxRadios.Controls.Add(this.radioButton3);
            this.groupBoxRadios.Controls.Add(this.radioButton2);
            this.groupBoxRadios.Controls.Add(this.radioButton1);
            this.groupBoxRadios.Location = new System.Drawing.Point(181, 12);
            this.groupBoxRadios.Name = "groupBoxRadios";
            this.groupBoxRadios.Size = new System.Drawing.Size(172, 167);
            this.groupBoxRadios.TabIndex = 1;
            this.groupBoxRadios.TabStop = false;
            this.groupBoxRadios.Text = "GroupBox de RadioButtons";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(34, 19);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 21);
            this.comboBox1.TabIndex = 2;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // groupBoxCombo
            // 
            this.groupBoxCombo.Controls.Add(this.labelCombo);
            this.groupBoxCombo.Controls.Add(this.buttonCombo);
            this.groupBoxCombo.Controls.Add(this.comboBox1);
            this.groupBoxCombo.Location = new System.Drawing.Point(3, 185);
            this.groupBoxCombo.Name = "groupBoxCombo";
            this.groupBoxCombo.Size = new System.Drawing.Size(172, 167);
            this.groupBoxCombo.TabIndex = 1;
            this.groupBoxCombo.TabStop = false;
            this.groupBoxCombo.Text = "GroupBox de ComboBox";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(181, 185);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(172, 160);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(6, 35);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(80, 17);
            this.checkBox1.TabIndex = 0;
            this.checkBox1.Text = "checkBox1";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(7, 58);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(80, 17);
            this.checkBox2.TabIndex = 1;
            this.checkBox2.Text = "checkBox2";
            this.checkBox2.UseVisualStyleBackColor = true;
            this.checkBox2.CheckedChanged += new System.EventHandler(this.checkBox2_CheckedChanged);
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Location = new System.Drawing.Point(7, 82);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(80, 17);
            this.checkBox3.TabIndex = 2;
            this.checkBox3.Text = "checkBox3";
            this.checkBox3.UseVisualStyleBackColor = true;
            this.checkBox3.CheckedChanged += new System.EventHandler(this.checkBox3_CheckedChanged);
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(7, 35);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(85, 17);
            this.radioButton1.TabIndex = 0;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "radioButton1";
            this.radioButton1.UseVisualStyleBackColor = true;
            this.radioButton1.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(7, 58);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(85, 17);
            this.radioButton2.TabIndex = 1;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "radioButton2";
            this.radioButton2.UseVisualStyleBackColor = true;
            this.radioButton2.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged);
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Location = new System.Drawing.Point(7, 82);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(85, 17);
            this.radioButton3.TabIndex = 2;
            this.radioButton3.TabStop = true;
            this.radioButton3.Text = "radioButton3";
            this.radioButton3.UseVisualStyleBackColor = true;
            this.radioButton3.CheckedChanged += new System.EventHandler(this.radioButton3_CheckedChanged);
            // 
            // buttonCombo
            // 
            this.buttonCombo.Location = new System.Drawing.Point(55, 59);
            this.buttonCombo.Name = "buttonCombo";
            this.buttonCombo.Size = new System.Drawing.Size(75, 23);
            this.buttonCombo.TabIndex = 3;
            this.buttonCombo.Text = "button1";
            this.buttonCombo.UseVisualStyleBackColor = true;
            this.buttonCombo.Click += new System.EventHandler(this.buttonCombo_Click);
            // 
            // labelCombo
            // 
            this.labelCombo.AutoSize = true;
            this.labelCombo.Location = new System.Drawing.Point(86, 43);
            this.labelCombo.Name = "labelCombo";
            this.labelCombo.Size = new System.Drawing.Size(16, 13);
            this.labelCombo.TabIndex = 4;
            this.labelCombo.Text = "...";
            // 
            // labelChecks
            // 
            this.labelChecks.AutoSize = true;
            this.labelChecks.Location = new System.Drawing.Point(9, 123);
            this.labelChecks.Name = "labelChecks";
            this.labelChecks.Size = new System.Drawing.Size(16, 13);
            this.labelChecks.TabIndex = 5;
            this.labelChecks.Text = "...";
            // 
            // labelRadios
            // 
            this.labelRadios.AutoSize = true;
            this.labelRadios.Location = new System.Drawing.Point(6, 123);
            this.labelRadios.Name = "labelRadios";
            this.labelRadios.Size = new System.Drawing.Size(16, 13);
            this.labelRadios.TabIndex = 6;
            this.labelRadios.Text = "...";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(368, 357);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.groupBoxCombo);
            this.Controls.Add(this.groupBoxRadios);
            this.Controls.Add(this.groupBoxChecks);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBoxChecks.ResumeLayout(false);
            this.groupBoxChecks.PerformLayout();
            this.groupBoxRadios.ResumeLayout(false);
            this.groupBoxRadios.PerformLayout();
            this.groupBoxCombo.ResumeLayout(false);
            this.groupBoxCombo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBoxChecks;
        private System.Windows.Forms.GroupBox groupBoxRadios;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.GroupBox groupBoxCombo;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.Label labelCombo;
        private System.Windows.Forms.Button buttonCombo;
        private System.Windows.Forms.Label labelChecks;
        private System.Windows.Forms.Label labelRadios;


    }
}

