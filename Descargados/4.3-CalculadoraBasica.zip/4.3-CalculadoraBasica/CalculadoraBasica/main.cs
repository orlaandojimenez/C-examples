﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CalculadoraBasica
{
    public partial class main : Form
    {
        public main()
        {
            InitializeComponent();
        }

        private void button_Calcular_Click(object sender, EventArgs e)
        {
            String operador = this.comboBox1.Text;
            double resultado = 0;
            double valor1 = 0;
            double valor2 = 0;

            //Obtenemos los valores de los TextBox's
            if (this.textBox_Val1.Text != "")
                valor1 = Convert.ToDouble(this.textBox_Val1.Text);
            else
                valor1 = 0;

            if (this.textBox_Val2.Text != "")
                valor2 = Convert.ToDouble(this.textBox_Val2.Text);
            else
                valor2 = 0;

            switch (operador)
            {
                case "+"://SUMA
                    resultado = doSuma(valor1, valor2);
                    break;

                case "-"://RESTA
                    resultado = doResta(valor1, valor2);
                    break;

                case "*"://MULTIPLICACION
                    resultado = doMult(valor1, valor2);
                    break;

                case "/"://DIVISION
                    resultado = doDiv(valor1, valor2);
                    break;

                case "pow"://POTENCIA
                    resultado = doPotencia(valor1, valor2);
                    break;

                case "log"://LOGARITMO NATURAL
                    resultado = Math.Log(valor1);
                    break;

                case "sqrt"://RAIZ CUADRADA
                    resultado = Math.Sqrt(valor1);
                    break;

                default://SIN OPERADOR
                    MessageBox.Show("Selecciona un operador");
                    break;
            }

            //Colocamos el resultado en el Label
            this.label_Resultado.Text = resultado.ToString();
        }

        private double doSuma(double valor1, double valor2)
        {
            double resultado = valor1 + valor2;
            return resultado;
        }

        private double doResta(double valor1, double valor2)
        {
            double resultado = valor1 - valor2;
            return resultado;
        }

        private double doMult(double valor1, double valor2)
        {
            double resultado = valor1 * valor2;
            return resultado;
        }

        private double doDiv(double valor1, double valor2)
        {
            double resultado = valor1 / valor2;
            return resultado;
        }

        private double doPotencia(double valor1, double valor2)
        {
            double resultado = Math.Round(5.7356,2);
            return resultado;
        }

    }
}
