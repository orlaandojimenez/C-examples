﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HolaFIME
{
    class HolaFimeForm
    {
        static void Main(string[] args)
        {//Recordar añadir System.Windows.Forms a las referencias!
            MessageBox.Show("Hola FIME");
        }
    }
}
