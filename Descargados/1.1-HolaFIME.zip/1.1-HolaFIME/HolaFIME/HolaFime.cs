﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HolaFIME
{
    class HolaFime
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hola FIME");
            Console.Read();
        }
    }
}