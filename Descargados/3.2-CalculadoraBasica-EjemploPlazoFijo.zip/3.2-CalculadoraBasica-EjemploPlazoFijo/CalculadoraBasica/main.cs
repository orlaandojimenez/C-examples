﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CalculadoraBasica
{
    public partial class main : Form
    {
        public main()
        {
            InitializeComponent();
        }

        private void button_Calcular_Click(object sender, EventArgs e)
        {
            //Obtenemos los datos iniciales
            double net = Convert.ToDouble(this.textBox_Val1.Text);
            double years = Convert.ToDouble(this.textBox_Val2.Text);

            //Seleccionamos el porcentaje de intereses
            double p = 0;
            if (this.comboBox1.Text == "4%")
            {
                p = 0.4;
            }
            else if (this.comboBox1.Text == "5%")
            {
                p = 0.5;
            }
            else if (this.comboBox1.Text == "6%")
            {
                p = 0.6;
            }
            else if (this.comboBox1.Text == "7%")
            {
                p = 0.7;
            }
            else if (this.comboBox1.Text == "8%")
            {
                p = 0.8;
            }
            else
            {
                return;//Rompe la ejecucion
            }

            //Creamos una String que contendra el mensaje del desgloze
            String text = "Year \t Saldo";
            text += "\n" + 0 + "\t" + net;

            //Realizamos las operaciones.
            int i = 0;
            double ganancia = 0.0;
            for (i = 1; i <= years; i++)
            {//Repetimes el ciclo tantos years se ocupe
                ganancia = net * p;          //Ganancia del year
                net += ganancia;
                text += "\n" + i + "\t" + net;
            }

            //Desplegamos resultados
            this.label_Resultado.Text = net.ToString();
            MessageBox.Show(text);
        }
    }
}
