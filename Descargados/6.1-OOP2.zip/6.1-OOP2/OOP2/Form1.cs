﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OOP2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            int numero1 = 0;
            int numero2 = 0;
            try
            {
                numero1 = 5 - 5;
                numero2 = 3 / numero1;
            }
            catch(Exception ex)
            {
                numero2 = 3;
                MessageBox.Show("Error en la división: " + ex.ToString());
            }
            finally
            {
                string msg = "";
                msg += "numero1 = " + numero1.ToString() + "\n";
                msg += "numero2 = " + numero2.ToString() + "\n";
                MessageBox.Show(msg);
            }
        }
    }
}
