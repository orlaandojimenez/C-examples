﻿using System;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;

namespace OOP3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {//ArrayList
            ArrayList myAL = new ArrayList();
            string msg = "";

            //Inserta elementos
            myAL.Add("Hello");
            myAL.Add("World");
            myAL.Add("!");

            //Accesa a los elementos one by one
            msg += myAL[0] + "\n";
            msg += myAL[1] + "\n";
            msg += myAL[2] + "\n";

            //Remueve elementos y agrega otros
            myAL.RemoveAt(1);//Elimina World
            myAL.Remove("!");//Elimina '!'
            myAL.Add("FIME");
            myAL.Add("!!!!");

            //Accesa a los elementos automaticamente
            msg += "\n\n\n";
            for (int i = 0; i < myAL.Count; i++)
                msg += myAL[i] + "\n";

            MessageBox.Show(msg);
        }

        private void button2_Click(object sender, EventArgs e)
        {//HashTables
            // Create a new hash table. 
            Hashtable openWith = new Hashtable();
            string msg = "";

            // Add some elements to the hash table. There are no  
            // duplicate keys, but some of the values are duplicates.
            openWith.Add("txt", "notepad.exe");
            openWith.Add("bmp", "paint.exe");
            openWith.Add("dib", "paint.exe");
            openWith.Add("rtf", "wordpad.exe");

            //Get the values manually
            msg += "Manually get elements:\n";
            msg += "txt: " + openWith["txt"] + "\n";
            msg += "dib: " + openWith["dib"] + "\n";
            msg += "rtf: " + openWith["rtf"] + "\n";

            // To get the values alone, use the Values property.
            msg += "\n\nVals:\n";
            ICollection valueColl = openWith.Values;
            foreach (string val in valueColl)
                msg += val + "\n";

            // To get the keys alone, use the Keys property.
            msg += "\n\nKeys:\n";
            ICollection keyColl = openWith.Keys;
            foreach (string key in keyColl)
                msg += key + "\n";

            MessageBox.Show(msg);
        }

    }
}
