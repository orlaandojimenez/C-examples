﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CalculadoraBasica
{
    public partial class main : Form
    {
        public main()
        {
            InitializeComponent();
        }

        private void button_Calcular_Click(object sender, EventArgs e)
        {
            int altura = Convert.ToInt32(this.textBox_Val1.Text);
            string c = this.comboBox1.Text;
            string text = "";
            if (c != "")
            {//Solo correr si se ha seleccionado un caracter
                for (int i = 0; i < altura; i++)
                {//Creamos el pino de arriba hacia abajo
                    for (int j = 0; j < (i+1); j++)
                    {
                        text += c;
                    }
                    text += "\n";//Espacio
                }
            }
            MessageBox.Show(text);
        }
    }
}
